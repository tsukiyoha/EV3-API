/*
 \file		test_compas.c
 \author	${user}
 \date		${date}
 \brief		Test du capteur boussole
*/

#include <ev3.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
//#include <c_i2c.h>
//#include <i2c/smbus.h>
#include <pthread.h>


#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  (byte & 0x80 ? '1' : '0'), \
  (byte & 0x40 ? '1' : '0'), \
  (byte & 0x20 ? '1' : '0'), \
  (byte & 0x10 ? '1' : '0'), \
  (byte & 0x08 ? '1' : '0'), \
  (byte & 0x04 ? '1' : '0'), \
  (byte & 0x02 ? '1' : '0'), \
  (byte & 0x01 ? '1' : '0') 


int main(void)
{
	//TODO Place here your variables
	InitEV3();
	int arret =1;// pour controler l' arret du programme
	int i = 0; 
	
	//int valeurSensorHT;// la valeur du capteur de position
	setAllSensorMode(NO_SEN, NO_SEN, NO_SEN, NO_SEN);// initialisation des capteurs
	ButtonWaitForAnyPress(0);
	LcdPrintf(1,"Ouverture\n");
	Wait(SEC_1);
	Ev3Clear();

	for(i = 0; i<5; i++){
		LcdTextf(1, 0, i*10 +5, "test %d",i);
	}

	while(arret == 1){

		if(ButtonIsDown(BTNCENTER)){
			arret=0;		
			LcdPrintf(1,"Fermeture\n");
			Wait(SEC_1);
		}
	}
	
	LcdPrintf(1,"Origin : Fin de thread\n");
	FreeEV3();
	return 0;
}
