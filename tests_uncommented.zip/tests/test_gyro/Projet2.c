/*
 \file		Projet2.c
 \author	${user}
 \date		${date}
 \brief		Accéléro_Stabiliseur
*/

#include <ev3.h>
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  (byte & 0x80 ? '1' : '0'), \
  (byte & 0x40 ? '1' : '0'), \
  (byte & 0x20 ? '1' : '0'), \
  (byte & 0x10 ? '1' : '0'), \
  (byte & 0x08 ? '1' : '0'), \
  (byte & 0x04 ? '1' : '0'), \
  (byte & 0x02 ? '1' : '0'), \
  (byte & 0x01 ? '1' : '0') 
  
int main(void)
{
	//TODO Place here your variables
	InitEV3();
	int arret =0;// pour controler l' arret du programme
	int valeurSensorLego, valeurSensorHT;// la valeur du capteur de position
	setAllSensorMode(TOUCH_PRESS, GYRO_SENSOR_HIT, NO_SEN, NO_SEN);// initialisation des capteurs
	while(arret == 0){// si on clique sur le capteur de contact
		arret = readSensor(IN_1);
		Wait(SEC_1);
	}
	LcdPrintf(1,"Ouverture\n");
	Wait(SEC_1);
	Ev3Clear();
	while(arret == 1){

		//valeurSensorLego=readSensor(IN_2);// lire la valeur du gyroscope LEGO
		//LcdPrintf(1,"LEGO gyro: %d\n", valeurSensorLego);
		
		//LcdPrintf(1,"\n\n\n");
		valeurSensorHT=readSensor(IN_2);// lire la valeur du gyroscope HiTechnic
		LcdPrintf(1,"HiTechnic gyro: %d\n", valeurSensorHT);
		
		/*LcdPrintf(1,"octet 0: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY(valeurSensorHT & 0xFF));
		LcdPrintf(1,"octet 1: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>8) & 0xFF));
		LcdPrintf(1,"octet 2: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>16) & 0xFF));
		LcdPrintf(1,"octet 3: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>24) & 0xFF));
		//LcdPrintf(1,"octet 4: %d\n", (valeurSensorHT>>32) & 0xFF);
		//LcdPrintf(1,"octet 5: %d\n", (valeurSensorHT>>40) & 0xFF);
		//LcdPrintf(1,"octet 6: %d\n", (valeurSensorHT>>48) & 0xFF);
		//LcdPrintf(1,"octet 7: %d\n", (valeurSensorHT>>56) & 0xFF);
		*/
		Wait(MS_100);
		Ev3Clear();
		if(readSensor(IN_1)==1){
			arret=0;		
			LcdPrintf(1,"Fermeture\n");
			Wait(SEC_2);
		}
	}



	FreeEV3();
	return 0;
}
