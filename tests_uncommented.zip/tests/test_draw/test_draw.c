/*
 \file		test_draw.c
 \author	${user}
 \date		${date}
 \brief		Test de dessin sur l'ecran LCD
*/

#include <ev3.h>
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  (byte & 0x80 ? '1' : '0'), \
  (byte & 0x40 ? '1' : '0'), \
  (byte & 0x20 ? '1' : '0'), \
  (byte & 0x10 ? '1' : '0'), \
  (byte & 0x08 ? '1' : '0'), \
  (byte & 0x04 ? '1' : '0'), \
  (byte & 0x02 ? '1' : '0'), \
  (byte & 0x01 ? '1' : '0') 
  
int main(void)
{
	//TODO Place here your variables
	InitEV3();
	int arret =1;// pour controler l' arret du programme
	int i = 0;
	LocationType points[5] = {{.X = 80, .Y = 60},{.X = 90, .Y = 70},{.X = 30, .Y = 100},{.X = 120, .Y = 90},{.X = 130, .Y = 100}};
	setAllSensorMode(NO_SEN, ANGLE_SENSOR_HIT, NO_SEN, TOUCH_PRESS);// initialisation des capteurs
	ButtonWaitForAnyPress(0);
	LcdPrintf(1,"Ouverture\n");
	Wait(SEC_1);
	Ev3Clear();
	
	displayText(5, 5, "test dessin : \n");
	CircleOut (20, 20, 10);
	LineOut(30,20,50,20);
	PointOut(20,20);
	RectOut(50,10,30,20);
	EllipseOut(130, 50, 40, 20);
	PolyOut(points, 5);
	
	/*
	for(i = 0; i<10; i++){
		LcdPrintf(1,"test\n");
	}
	ButtonWaitForAnyPress(0);
	ClearLine(5);
	*/
	while(arret == 1){		
		if(ButtonIsDown(BTNCENTER)){
			arret=0;
			LcdClean();	
			LcdPrintf(1,"Fermeture\n");
			Wait(SEC_1);
		}
	}

	FreeEV3();
	return 0;
}
