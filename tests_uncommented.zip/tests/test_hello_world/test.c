#include <ev3.h>

int main(void)
{
	InitEV3();
	
	LcdPrintf(1,"Hello Wordl!\n");
	Wait(SEC_2);
	
	FreeEV3();
	return 0;
}
