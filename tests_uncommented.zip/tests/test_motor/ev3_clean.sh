#!/bin/bash

if [ "$#" -ne 1 ]; then
	echo "Illegal number of parameters, use $0 name_of_program"
	echo
fi

echo "Deleting file from EV3"
ev3 rm /home/root/lms2012/prjs/$1/$1

echo

echo "Deleting folder file"
ev3 rm /home/root/lms2012/prjs/$1/$1.rbf
echo

echo "Deleting actual folder on EV3"
ev3 rm /home/root/lms2012/prjs/$1


echo "DONE"
echo
