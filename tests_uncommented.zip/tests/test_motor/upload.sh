#!/bin/bash

if [ "$#" -ne 1 ]; then
	echo "Illegal number of parameters, use $0 name_of_program"
	echo
fi

echo "Creating actual folder on EV3"
ev3 mkdir /home/root/lms2012/prjs/$1

echo

echo "Uploading file to EV3"
ev3 up $1 /home/root/lms2012/prjs/$1/$1

echo

echo "Creating folder file"
ev3 mkrbf /home/root/lms2012/prjs/$1/$1 $1.rbf
echo

echo "Uploading folder file"
ev3 up $1.rbf /home/root/lms2012/prjs/$1/$1.rbf
echo

echo "DONE"
echo
