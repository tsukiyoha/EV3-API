/*
 \file		test_motor.c
 \author	${user}
 \date		${date}
 \brief		Test de commande des moteurs
*/

#include <ev3.h>
#include <unistd.h>
#include <linux/i2c-dev.h>
//#include <c_i2c.h>
//#include <i2c/smbus.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>


#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  (byte & 0x80 ? '1' : '0'), \
  (byte & 0x40 ? '1' : '0'), \
  (byte & 0x20 ? '1' : '0'), \
  (byte & 0x10 ? '1' : '0'), \
  (byte & 0x08 ? '1' : '0'), \
  (byte & 0x04 ? '1' : '0'), \
  (byte & 0x02 ? '1' : '0'), \
  (byte & 0x01 ? '1' : '0') 

typedef struct pid_struct
{
	int setPoint, p, i, d;
	
} PID;

int runPidThread = 0;

void* runMotor(void* args)
{
	PID *param = (PID *)args;
	int sensorValue, newSetPoint;
	int error, delta_error, previous_error = 0, sum_error = 0;
	LcdPrintf(1,"thread : GO\n");
	Wait(SEC_1);
	Ev3Clear();
	
	while(1){
		sensorValue = MotorPower(OUT_A);
		error = param->setPoint - sensorValue;
		delta_error = error - previous_error;
		sum_error += error;
		newSetPoint = error * param->p + sum_error * param->i + delta_error * param->d;
		previous_error = error;
		OnFwdReg(OUT_A, newSetPoint);
		
		TermPrintf("consigne : %d\n",param->setPoint);
		TermPrintf("newConsigne : %d\n",newSetPoint);
		TermPrintf("p : %d\n",param->p);
		TermPrintf("i : %d\n",param->i);
		TermPrintf("d : %d\n",param->d);
		TermPrintf("error : %d\n",error);
		TermPrintf("previous_error : %d\n",previous_error);
		TermPrintf("delta_error : %d\n",delta_error);
		TermPrintf("sum_error : %d\n",sum_error);
		
		TermPrintf("runPidThread : %d\n",runPidThread);
		if(!runPidThread) break;
		Wait(MS_100);
		Ev3Clear();
		
	}
	TermPrintf("runPidThread : %d\n",runPidThread);
	Wait(SEC_1);
	return NULL;	
}

int main(void)
{
	//TODO Place here your variables
	InitEV3();
	int arret = 1;// pour controler l' arret du programme
	pid_t pid;
	
	pthread_t thread;
	PID param = {40,1,1,5};
	
	//int valeurSensorHT;// la valeur du capteur de position
	setAllSensorMode(NO_SEN, NO_SEN, NO_SEN, NO_SEN);// initialisation des capteurs
	ButtonWaitForAnyPress(0);
	LcdPrintf(1,"Ouverture\n");
	Wait(SEC_1);
	Ev3Clear();

	LcdPrintf(1,"Origin : Lancement de thread\n");
	runPidThread = 1;
	pthread_create(&thread, NULL, &runMotor, &param);

	while(arret == 1){

		if(ButtonIsDown(BTNCENTER)){
			arret=0;		
			LcdPrintf(1,"Fermeture\n");
			Wait(SEC_1);
		}
	}
	
	Ev3Clear();
	
	runPidThread = 0;
	pthread_join(thread, NULL);
	Off(OUT_A);
	LcdPrintf(1,"Origin : Fin de thread\n");
	FreeEV3();
	return 0;
}
