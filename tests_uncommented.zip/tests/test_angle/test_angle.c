/*
 \file		test_angle.c
 \author	${user}
 \date		${date}
 \brief		Test du capteur d'angle
*/

#include <ev3.h>
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  (byte & 0x80 ? '1' : '0'), \
  (byte & 0x40 ? '1' : '0'), \
  (byte & 0x20 ? '1' : '0'), \
  (byte & 0x10 ? '1' : '0'), \
  (byte & 0x08 ? '1' : '0'), \
  (byte & 0x04 ? '1' : '0'), \
  (byte & 0x02 ? '1' : '0'), \
  (byte & 0x01 ? '1' : '0') 
  
int main(void)
{
	//TODO Place here your variables
	InitEV3();
	int arret =1;// pour controler l' arret du programme
	int valeurSensorHT;// la valeur du capteur de position
	setAllSensorMode(NO_SEN, ANGLE_SENSOR_HIT, NO_SEN, TOUCH_PRESS);// initialisation des capteurs
	ButtonWaitForAnyPress(0);
	LcdPrintf(1,"Ouverture\n");
	Wait(SEC_1);
	Ev3Clear();
	while(arret == 1){

		//LcdPrintf(1,"\n\n\n");
		valeurSensorHT=readSensor(IN_2);// lire la valeur du gyroscope HiTechnic
		//LcdPrintf(1,"HiTechnic angle: %d\n", valeurSensorHT);
		//LcdPrintf(1,"HiTechnic angle final ?: %d\n", (valeurSensorHT&0x00FF)*2+(valeurSensorHT&0xFF00));
		
		/*LcdPrintf(1,"octet 0: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY(valeurSensorHT & 0xFF));
		LcdPrintf(1,"octet 1: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>8) & 0xFF));
		//LcdPrintf(1,"octet 2: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>16) & 0xFF));
		//LcdPrintf(1,"octet 3: "BYTE_TO_BINARY_PATTERN"\n", BYTE_TO_BINARY((valeurSensorHT>>24) & 0xFF));
		*/
		/*
		LcdPrintf(1,"octet 0: %d\n", valeurSensorHT & 0xFF);
		LcdPrintf(1,"octet 1: %d\n", (valeurSensorHT>>8) & 0xFF);
		LcdPrintf(1,"octet 2: %d\n", (valeurSensorHT>>16) & 0xFF);
		LcdPrintf(1,"octet 3: %d\n", (valeurSensorHT>>24) & 0xFF);
		LcdPrintf(1,"octet 4: %d\n", (valeurSensorHT>>32) & 0xFF);
		LcdPrintf(1,"octet 5: %d\n", (valeurSensorHT>>40) & 0xFF);
		LcdPrintf(1,"octet 6: %d\n", (valeurSensorHT>>48) & 0xFF);
		LcdPrintf(1,"octet 7: %d\n", (valeurSensorHT>>56) & 0xFF);
		*/
		Wait(MS_100);
		Ev3Clear();
		if(ButtonIsDown(BTNCENTER)){
			arret=0;		
			LcdPrintf(1,"Fermeture\n");
			Wait(SEC_1);
		}
	}



	FreeEV3();
	return 0;
}
